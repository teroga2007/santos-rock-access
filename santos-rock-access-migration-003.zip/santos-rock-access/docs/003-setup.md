# Migration 003 — identity and roles

## Purpose
- Automatically create a `profiles` record for new Supabase Auth users.
- Allow organization admins to create events and assign event members via authenticated RPCs.
- Allow owners to add an *existing Auth user* as an organization admin.
- Preserve read-only direct table access from migration 001.

## Critical limitation
This migration **does not** create the first owner or send invitations. Do not turn on public sign-up. Configure **Supabase Dashboard → Authentication → Providers → Email** to disable public sign-ups (UI wording may vary). Later, a trusted server-side endpoint will call `auth.admin.inviteUserByEmail()` using a secret key stored only server-side, and assign organization membership only after verifying the invitation workflow. Do not put the service-role key in the browser or Netlify `VITE_` variables.

## First-owner bootstrap (manual, one time)
1. In Supabase Dashboard, invite your own email from **Authentication → Users → Invite user**. Accept the invitation and set your password.
2. Find your user ID in Authentication → Users.
3. In SQL Editor, execute the following, replacing the UUID with your *actual* Auth user ID. Never use a random UUID:

```sql
begin;
insert into public.organizations (name, slug)
values ('Santos Rock', 'santos-rock')
on conflict (slug) do nothing;

insert into public.organization_members (organization_id, user_id, role)
select id, 'REPLACE_WITH_YOUR_AUTH_USER_UUID'::uuid, 'owner'::public.org_role
from public.organizations where slug = 'santos-rock'
on conflict (organization_id, user_id) do nothing;
commit;
```

**Safety:** Before applying the bootstrap, verify that `santos-rock` is the intended organization and the Auth UUID is yours. This script intentionally does not overwrite existing memberships. Do not add this personalized bootstrap to the shared migration.

## Local / remote execution
Prefer local Docker development and a staging Supabase project for testing. If using the current linked remote development project, run `npx supabase db push --dry-run --remote`, inspect the single pending migration, then `npx supabase db push --remote`.

## Smoke tests
1. `select count(*) from public.profiles;` should include Auth users.
2. `select proname from pg_proc join pg_namespace n on n.oid=pronamespace where n.nspname='public' and proname in ('create_event','assign_event_member','add_organization_member');` should return three functions.
3. As a non-owner authenticated user, `add_organization_member` must reject.
4. As a scanner, `create_event` and `assign_event_member` must reject.
5. As owner, create an event, then check audit_logs.

## Security follow-ups
- Test functions with actual JWTs, not only SQL Editor (`postgres` bypasses RLS).
- Verify `auth.users` invitation lifecycle and account confirmation.
- Add protected invite endpoint and revocation/removal RPCs; never expose an admin secret in the frontend.
- Restrict role-management RPCs further if product needs event admins (rather than only organization admins) to manage their event.
